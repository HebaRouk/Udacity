# In-context Learning
> Large language models (LLMs) demonstrate an in-context learning (ICL) ability, that is, learning from a few examples in the context.
## Useful Resource
- [ICL_PaperList](https://github.com/dqxiu/ICL_PaperList) - An active repository for ICL paper list.
